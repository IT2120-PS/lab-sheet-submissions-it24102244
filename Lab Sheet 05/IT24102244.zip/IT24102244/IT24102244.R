setwd("E:\\SLIIT_Bacholer\\_2_Year_sem1\\Probability&Statistic\\lab4\\IT24102244")



# (1)
Delivery_Times <- read.table("Exercise - Lab 05.txt",header = TRUE)
fix(Delivery_Times)
attach(Delivery_Times)

# (2)
histogram <- hist(Delivery_Time_.minutes., main = "Histogram for Delivery Time",breaks = seq(20, 70, length = 10),right = TRUE)


# (4)
freq <- histogram$counts
cum.freq <- cumsum(freq)

new <- c()

for(i in 1:length(breaks)){
  if(i==1){
    new[i] <- 0
  } else {
    new[i] <- cum.freq[i-1]
  }
}

plot(breaks, new, type = "l",
     main = "Cumulative Frequency",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     ylim = c(0, max(cum.freq)))

cbind(Upper = breaks, CumFreq = new)

