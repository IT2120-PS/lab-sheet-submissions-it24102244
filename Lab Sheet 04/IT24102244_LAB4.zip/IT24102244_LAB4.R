setwd("C:/Users/it24102244/Desktop/Lab4")

branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
head(branch_data)
fix(branch_data)
attach(branch_data)
# 2. Identify the variable type and scale of measurement for each variable.
str(branch_data)

#3.
boxplot(branch_data$Sales_X1, main = "Boxplot of Sales", outline = TRUE,outpch = 8, horizontal = TRUE)

summary(branch_data$Advertising_X2)

IQR(branch_data$Advertising_X2, na.rm = TRUE)

find_outlier <- function(x){
  x <- x[!is.na(x)]
  
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- Q3 - Q1
  
  
  lower_fence <- Q1 - 1.5 * IQR_value
  upper_fence <- Q3 + 1.5 * IQR_value
  
  outliers <- x[x < lower_fence | x > upper_fence]
  
  return(outliers)
}

find_outlier(branch_data$Years_X3)