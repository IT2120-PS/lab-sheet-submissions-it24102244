setwd("E:\\SLIIT_Bacholer\\_2_Year_sem1\\Probability&Statistic\\Lab06_ps")


#QUESTION 1
#1
#Bonomial distribution because each student either 
#passes or fails and each event is independent of one another.

#2
pbinom(47,50,0.85, lower.tail = TRUE)


#QUESTION 2
#1
#Number of calls received in one hour

#2
#Poisson distribution because there is a historical value involved.

#3
dpois(15,12)
